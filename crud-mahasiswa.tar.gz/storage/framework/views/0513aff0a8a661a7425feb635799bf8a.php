<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'CRUD Data Mahasiswa'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif}
        button,input[type="button"],input[type="submit"],input[type="reset"]{background:none;border:none;padding:0;font:inherit;cursor:pointer;outline:inherit}
        body{background:#f5f8ff;color:#333;min-height:100vh;padding:20px;line-height:1.6}
        .container{max-width:1000px;margin:30px auto;background:white;border-radius:16px;overflow:hidden;box-shadow:0 8px 25px rgba(67,97,238,0.12)}
        .header{background:linear-gradient(135deg,#4361ee 0%,#3a0ca3 100%);padding:20px 30px;color:white;display:flex;align-items:center;gap:12px}
        .header h1{font-size:1.5rem;font-weight:700}
        .content{padding:25px 30px}
        .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 20px;border-radius:8px;font-weight:600;font-size:1rem;cursor:pointer;transition:all 0.2s;border:none}
        .btn:hover{transform:translateY(-2px);box-shadow:0 4px 10px rgba(0,0,0,0.1)}
        .btn-primary{background:linear-gradient(135deg,#4361ee 0%,#3a0ca3 100%);color:white}
        .btn-success{background:linear-gradient(135deg,#06d6a0 0%,#048a64 100%);color:white}
        .btn-outline{background:transparent;color:#4361ee;border:2px solid #4361ee}
        .btn-outline:hover{background:rgba(67,97,238,0.05)}
        .btn-danger{background:linear-gradient(135deg,#ef476f 0%,#b5174a 100%);color:white}
        .btn-icon{width:36px;height:36px;padding:0;border-radius:50%;display:inline-flex;align-items:center;justify-content:center}
        .action-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:25px}
        .action-bar h2{font-size:1.4rem;color:#2b2d42;font-weight:700;display:flex;align-items:center;gap:10px}
        .card{background:white;border-radius:12px;padding:20px;margin-bottom:20px;border:1px solid #eef2f7}
        table{width:100%;border-collapse:collapse;margin:15px 0}
        th{background:#f8f9fc;color:#4361ee;font-weight:700;padding:14px 18px;text-align:left;border-bottom:2px solid #eef2f7}
        td{padding:12px 18px;border-bottom:1px solid #f0f4f8}
        .action-cell{display:flex;gap:8px}
        .footer{padding:15px;text-align:center;color:#6c757d;border-top:1px solid #f0f4f8;background:#f8fafc}
        .form-group{margin-bottom:18px}
        label{display:block;margin-bottom:6px;font-weight:600;color:#2b2d42}
        input,select,textarea{width:100%;padding:12px 15px;border-radius:8px;border:1px solid #e2e8f0;font-size:1rem}
        input:focus,select:focus,textarea:focus{outline:none;border-color:#4361ee;box-shadow:0 0 0 3px rgba(67,97,238,0.15)}
        .form-row{display:flex;gap:15px;margin-bottom:15px}
        .form-column{flex:1}
        @media (max-width:768px){
            .container{margin:20px auto}
            .header,.content,.footer{padding:15px}
            .form-row{flex-direction:column;gap:10px}
            .action-bar{flex-direction:column;align-items:flex-start;gap:12px}
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-user-graduate"></i>
            <h1>MANAJEMEN DATA MAHASISWA</h1>
        </div>

        <div class="content">
            <?php if(session('success')): ?>
            <div class="card" style="background: rgba(6, 214, 160, 0.1); color: #0a7d5c; border-left: 4px solid #06d6a0;">
                <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>)
            <div class="card" style="background: rgba(239, 71, 111, 0.1); color: #b53b57; border-left: 4px solid #ef476f;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="footer">
            <p>&copy; <?php echo e(date('Y')); ?> Sistem Data Mahasiswa</p>
        </div>
    </div>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /data/data/com.termux/files/home/crud-mahasiswa/resources/views/layouts/app.blade.php ENDPATH**/ ?>